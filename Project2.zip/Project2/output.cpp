#include <iostream>

extern int a, b, c, d, first_num, second_num;

void output()
{
	std::cout << a << "/" << b << " + " << c << "/" << d << " = " << first_num << "/" << second_num << std::endl ;
	std::cout << a << "/" << b << " + " << c << "/" << d << " = " << (float)first_num / second_num;
}