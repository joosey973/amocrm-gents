#pragma once

void input();