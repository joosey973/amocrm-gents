extern int a, b, c, d, first_num, second_num;

void summ()
{

	first_num = a * d + b * c;
	second_num = b * d;
}