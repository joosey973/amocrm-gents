#pragma once

void output();