#include <iostream>
#include <Windows.h>
#include <conio.h>
#include "input.h"
#include "summa.h"
#include "output.h"


int a, b, c, d;
int first_num, second_num;

int main()
{
	SetConsoleOutputCP(1251);
	std::cout << "Введите операцию в виде a/b + c/d: ";
	input();
	summ();
	output();
}