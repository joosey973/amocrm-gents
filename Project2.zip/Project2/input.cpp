#include <iostream>

extern int a, b, c, d;

void input() {
	char ch, oper;
	std::cin >> a >> ch >> b >> oper >> c >> ch >> d;
}