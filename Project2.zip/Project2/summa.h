#pragma once

void summ();