#include <iostream>
#include <Windows.h>
#include <conio.h>


extern int month_num, first_day_num;


void input()
{
	SetConsoleOutputCP(CP_UTF8);
	std::cout << "Введите номер месяца: ";
	std::cin >> month_num;
	std::cout << "Введите номер первого дня месяца: ";
	std::cin >> first_day_num;
}


