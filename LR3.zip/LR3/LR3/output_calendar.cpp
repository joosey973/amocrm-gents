#include <iostream>
#include <Windows.h>
#include <conio.h>
#include <iomanip>
#include <string>

extern int first_day_num, count_of_days;
extern std::string month;

void output_calendar()
{
    std::cout << std::setw(23) << month << std::endl;

    if (!(1 <= first_day_num and first_day_num <= 7))
    {
        first_day_num = 1;
    }

    for (int i = 1; i < first_day_num; i++) {
        std::cout << std::setw(4) << "";
    }

    for (int day = 1; day <= count_of_days; day++) {
        std::cout << std::setw(4) << day;

        if ((first_day_num - 1 + day) % 7 == 0) {
            std::cout << std::endl;
        }
    }

    std::cout << std::endl << std::endl;
}