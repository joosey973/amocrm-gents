#include <iostream>
#include <cmath>
#include <Windows.h>
#include <conio.h>


float iter_cube(float arg)
{
	float temp_arg = arg / 3.0;
	float start_arg;
	do {
		start_arg = temp_arg;
		temp_arg = (arg / (temp_arg * temp_arg) + 2 * temp_arg) / 3.0;
	} while (std::abs(start_arg - temp_arg) > 1e-10);

	return temp_arg;
}


int main()
{
	SetConsoleOutputCP(CP_UTF8);
	float arg;
	std::cout << "Введите число: ";
	std::cin >> arg;
	std::cout << "Стандартная формула: корень кубический из числа " << arg << " = " << pow(arg, (1 / 3.0)) << std::endl;
	std::cout << "Итерационная формула: корень кубический из числа " << arg << " = " << iter_cube(arg);
}