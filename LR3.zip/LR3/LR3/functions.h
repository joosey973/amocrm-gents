#pragma once

void input();
void get_month_and_count_of_days();
void output_calendar();