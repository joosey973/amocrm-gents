#include <string>

extern int month_num, count_of_days;
extern std::string month;


void get_month_and_count_of_days()
{
	
	enum Months { JAN = 1, FEB, MAR, APR, MAY, JUN, JUL, AUG, SEP, OCT, NOV, DEC };

	switch (month_num)
	{
	case JAN: month = "Январь"; break;
	case FEB: month = "Февраль"; break;
	case MAR: month = "Март"; break;
	case APR: month = "Апрель"; break;
	case MAY: month = "Май"; break;
	case JUN: month = "Июнь"; break;
	case JUL: month = "Июль"; break;
	case AUG: month = "Август"; break;
	case SEP: month = "Сентябрь"; break;
	case OCT: month = "Октябрь"; break;
	case NOV: month = "Ноябрь"; break;
	case DEC: month = "Декабрь"; break;
	}
	if (month_num == 4 or month_num == 6 or month_num == 9 or month_num == 11)
	{
		count_of_days = 30;
	}
	else if (month_num == 2)
	{
		count_of_days = 28;
	}
	else {
		count_of_days = 31;
	}
}