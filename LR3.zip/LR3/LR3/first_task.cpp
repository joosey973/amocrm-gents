#include "functions.h"
#include <string>

int month_num, first_day_num, count_of_days;
std::string month;

int main()
{
	input();
	get_month_and_count_of_days();
	output_calendar();
}