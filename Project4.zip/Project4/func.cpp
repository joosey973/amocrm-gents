#include <iostream>
#include "variables.h"
#include <Windows.h>
#include <conio.h>

int x, y, z, absX, minValue;

void input()
{
	SetConsoleOutputCP(1251);
	std::cout << "Введите число x: ";
	std::cin >> x;
	std::cout << "Введите два целых числа y и z: ";
	std::cin >> y >> z;
}

void solve()
{
	absX = (x >= 0) ? x : -x;
	minValue = (y > z) ? z : y;
}

void output()
{
	SetConsoleOutputCP(1251);
	std::cout << "Модуль числа" << x << " = " << absX << std::endl;
	std::cout << "Минимум из чисел " << y << " и " << z << " = " << minValue << std::endl;
}

