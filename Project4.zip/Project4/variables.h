#pragma once

extern int x, y, z;
extern int absX, minValue;