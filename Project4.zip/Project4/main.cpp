#include "func.h"


int main()
{
	input();
	solve();
	output();
}