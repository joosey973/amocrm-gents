#pragma once
void input();
void solve();
void output();