#include <iostream>
#include <Windows.h>
#include <conio.h>


int main()
{
	SetConsoleOutputCP(1251);
	int val;
	std::cout << "Введите любое четырехзначное число: ";
	std::cin >> val;
	std::cout << "Вы ввели число: " << val << std::endl;
	std::cout << "Перевернутое число: " << val % 10 << val / 10 % 10 << val / 100 % 10 << val / 1000;
}