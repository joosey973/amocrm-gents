#include <iostream>
#include <iomanip>
#include <cmath>
#include <Windows.h>
#include <conio.h>

int main()
{
	SetConsoleOutputCP(CP_UTF8);
	
	double S0, a;
	int N;
	std::cout << "Введите начальную сумму, руб. = ";
	std::cin >> S0;
	std::cout << "Введите размер ставки, % = ";
	std::cin >> a;
	std::cout << "Введите срок инвестирования, лет = ";
	std::cin >> N;
	double simple_percent = S0 * (1 + a / 100.0 * N);
	double hard_percent = S0 * pow((1 + a / 100.0), N);
	double delta_S_simple = simple_percent - S0, delta_S_hard = hard_percent - S0;
	double dohodn_simple = (delta_S_simple / S0) / N * 100.0, dohodn_hard = (delta_S_hard / S0) / N * 100.0;
	std::cout << std::fixed << std::setprecision(2);
	std::cout << std::right << std::setw(63) << "Простой процент"
		<< std::right << std::setw(31) << "Сложный процент" << std::endl;
	std::cout << std::left << std::setw(30) << "Начальная сумма (S_нач), руб."
		<< std::right << std::setw(15) << S0
		<< std::right << std::setw(18) << S0 << std::endl;

	std::cout << std::left << std::setw(30) << "Конечная сумма (S_кон), руб."
		<< std::right << std::setw(16) << simple_percent
		<< std::right << std::setw(18) << hard_percent << std::endl;

	std::cout << std::left << std::setw(30) << "Полученный доход (ΔS), руб."
		<< std::right << std::setw(16) << delta_S_simple
		<< std::right << std::setw(18) << delta_S_hard << std::endl;

	std::cout << std::left << std::setw(30) << "Доходность годовых (D), %"
		<< std::right << std::setw(16) << dohodn_simple
		<< std::right << std::setw(18) << dohodn_hard << std::endl;
}