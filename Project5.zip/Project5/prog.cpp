#include <iostream>


int main()
{
	char ltr1, ltr2;
	char oper1, oper2;
	std::cout << "Введите любые две буквы латинского алфавита: ";
	std::cin >> ltr1 >> ltr2;
	std::cout << "Введите любые два символа арифметических операций: ";
	std::cin >> oper1 >> oper2;

	int ltr1Val = ltr1, ltr2Val = ltr2;

	int oper1Val = (int)oper1;
	int oper2Val = (int)oper2;
	std::cout << "Целочисленное значение буквы " << ltr1 << " = " << ltr1Val << std::endl;
	std::cout << "Целочисленное значение буквы " << ltr2 << " = " << ltr2Val << std::endl;
	std::cout << "Целочисленное значение символа " << oper1 << " = " << oper1Val << std::endl;
	std::cout << "Целочисленное значение символа " << oper2 << " = " << oper2Val << std::endl;
}